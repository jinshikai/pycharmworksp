#simple tax
print("Welcome to the Tax System")
salary=float(input("Enter salary amount:"))
if 0<salary<10000:
    print("You do not need to pay any tax.")
elif salary<2000:
    tax_num=salary*0.05
    print(f"Please pay ${tax_num} for your tax.")
else:
    tax_num=salary*0.1
    print(f"Please pay ${tax_num} for your tax.")